package com.inspheris.sso.idau;

public class OpenIDIdPApplication extends org.atricore.idbus.capabilities.openid.ui.internal.OpenIDIdPApplication {

    //  Simple java class that extends a parent
}
